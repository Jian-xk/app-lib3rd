extern void print(void);

int main(void)
{
  print();
  return 0;
}
