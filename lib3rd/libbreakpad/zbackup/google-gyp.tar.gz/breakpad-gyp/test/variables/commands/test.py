print "sample\\path\\foo.cpp"
