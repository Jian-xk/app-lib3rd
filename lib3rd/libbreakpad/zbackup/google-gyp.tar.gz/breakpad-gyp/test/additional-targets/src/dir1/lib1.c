#ifdef _WIN32
__declspec(dllexport)
#endif
int func1(void) {
  return 42;
}
