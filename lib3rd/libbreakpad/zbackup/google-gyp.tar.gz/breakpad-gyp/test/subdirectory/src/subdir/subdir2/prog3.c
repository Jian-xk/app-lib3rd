#include <stdio.h>

int main(void)
{
  printf("Hello from prog3.c\n");
  return 0;
}
