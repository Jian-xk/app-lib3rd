From bogus1.cc
