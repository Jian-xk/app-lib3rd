#include <stdio.h>

int main(void)
{
  printf("Hello from prog1.c\n");
  return 0;
}
