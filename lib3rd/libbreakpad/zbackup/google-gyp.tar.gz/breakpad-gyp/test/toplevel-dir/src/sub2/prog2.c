#include <stdio.h>

int main(void)
{
  printf("Hello from prog2.c\n");
  return 0;
}
