import Foundation

public class GypSwiftTest {
  let myProperty = false

  init() {
    self.myProperty = true
  }
}