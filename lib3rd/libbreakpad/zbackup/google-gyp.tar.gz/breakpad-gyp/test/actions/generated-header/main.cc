#include <stdio.h>

#include "MyHeader.h"

int main() {
  printf("%s\n", kFoo);
}
